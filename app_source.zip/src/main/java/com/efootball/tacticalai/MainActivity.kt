package com.efootball.tacticalai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

/**
 * MainActivity.kt (v3.0)
 *
 * Manages:
 * 1. Requesting `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` (`SYSTEM_ALERT_WINDOW`).
 * 2. Copying pre-trained `.onnx` models from `assets/` into local storage for JNI/ONNX C++ & NNAPI loading.
 * 3. Requesting `MediaProjection` screen capture permission and launching `TacticalCaptureAndOverlayService`.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusTv: TextView
    private lateinit var logTv: TextView

    companion object {
        private const val REQ_OVERLAY_PERMISSION = 2001
        private const val REQ_MEDIA_PROJECTION = 2002

        init {
            try {
                System.loadLibrary("efootball_tactical_native")
            } catch (e: UnsatisfiedLinkError) {
                // Native library loaded when compiled with NDK
            }
        }
    }

    external fun initOnnxNativeEngine(visionModelPath: String, tacticalModelPath: String, useNnapi: Boolean): Boolean

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }

        statusTv = TextView(this).apply {
            textSize = 15f
            text = "eFootball Tactical AI v3.0 — Floating HUD & 360° Autonomous Brain"
        }

        val btnGrantOverlay = Button(this).apply {
            text = "1. Cấp quyền Hiển thị Hub Nổi (Overlay Permission)"
            setOnClickListener { checkAndRequestOverlayPermission() }
        }

        val btnLaunchHud = Button(this).apply {
            text = "2. Khởi chạy Floating HUD & Bắt hình MediaProjection"
            setOnClickListener { startCaptureAndFloatingHud() }
        }

        val btnStopHud = Button(this).apply {
            text = "3. Tắt toàn bộ Floating HUD & Giải phóng tài nguyên"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TacticalCaptureAndOverlayService::class.java))
                appendLog("Đã dừng TacticalCaptureAndOverlayService.")
            }
        }

        logTv = TextView(this).apply {
            textSize = 12f
            text = "[NHẬT KÝ HỆ THỐNG]\n"
        }

        root.addView(statusTv)
        root.addView(btnGrantOverlay)
        root.addView(btnLaunchHud)
        root.addView(btnStopHud)
        root.addView(ScrollView(this).apply { addView(logTv) })

        setContentView(root)
        stageAssetsModelsAndInitEngine()
    }

    private fun appendLog(msg: String) {
        logTv.append("• $msg\n")
    }

    private fun stageAssetsModelsAndInitEngine() {
        try {
            val outDir = File(filesDir, "models").apply { mkdirs() }
            val visionModel = File(outDir, "efootball_vision_roi_classifier.onnx")
            val tacticalModel = File(outDir, "efootball_tactical_scorer.onnx")

            for (fileName in listOf("efootball_vision_roi_classifier.onnx", "efootball_tactical_scorer.onnx")) {
                val targetFile = File(outDir, fileName)
                if (!targetFile.exists()) {
                    try {
                        assets.open("models/$fileName").use { input ->
                            FileOutputStream(targetFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                        appendLog("Đã sao chép model từ assets: $fileName")
                    } catch (e: Exception) {
                        appendLog("Chưa có $fileName trong assets, dùng đường dẫn ngoài hoặc nhân C++ xT.")
                    }
                }
            }

            try {
                val ok = initOnnxNativeEngine(visionModel.absolutePath, tacticalModel.absolutePath, true)
                appendLog("Khởi tạo ONNX C++ Native Engine (NNAPI=true): $ok")
            } catch (e: UnsatisfiedLinkError) {
                appendLog("Sẵn sàng ở chế độ Kotlin/Shell hybrid.")
            }
        } catch (e: Exception) {
            appendLog("Lỗi chuẩn bị model: ${e.message}")
        }
    }

    private fun checkAndRequestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY_PERMISSION)
        } else {
            appendLog("Quyền SYSTEM_ALERT_WINDOW đã được cấp sẵn sàng.")
        }
    }

    private fun startCaptureAndFloatingHud() {
        if (!Settings.canDrawOverlays(this)) {
            appendLog("Vui lòng cấp quyền Overlay trước khi mở Floating HUD!")
            checkAndRequestOverlayPermission()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY_PERMISSION) {
            appendLog("Kết quả quyền Overlay: canDrawOverlays=${Settings.canDrawOverlays(this)}")
        } else if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val svcIntent = Intent(this, TacticalCaptureAndOverlayService::class.java).apply {
                putExtra("RESULT_CODE", resultCode)
                putExtra("DATA_INTENT", data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
            appendLog("Đã bật Floating HUD! Hãy mở eFootball Mobile và bấm [▶ START AI].")
        }
    }
}
