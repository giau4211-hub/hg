package com.efootball.tacticalai

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * TacticalCaptureAndOverlayService.kt (v3.0 Full Autonomous Tactical HUD & Controller)
 *
 * Implements Section 2.C, 2.D & Section 3.1:
 * 1. Draggable Floating Hub (`WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY`) with:
 *    - Toggle Button: `[▶ START AI]` / `[⏹ STOP AI]`
 *    - Mini Status Display: FPS, Current Decision (`PASS_SAFE`, `DRIBBLE_SPACE`, `CONTAIN_DEFENSE`...), Latency (ms)
 *    - Quick Stance Switch: `"Attacking"` / `"Balanced"` / `"Defensive"`
 * 2. High-Speed `MediaProjection` + `ImageReader` capture pipeline feeding the C++ JNI / ONNX Runtime Native Engine.
 * 3. `VirtualTouchController` mapping `(ActionType, AngleDeg, PowerRatio, DurationMs)` into:
 *    - 360-degree smooth analog swipe around `(396, 1517)`
 *    - Right-cluster 4-button actions (`Pass/Switch: 2342x1670`, `Through/Match-up: 2433x1300`,
 *      `Shoot/Tackle: 2775x1180`, `Dash/Pressure: 2765x1632`) including single tap, power hold, and directional flicks.
 */
class TacticalCaptureAndOverlayService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var visionThread: HandlerThread? = null
    private var visionHandler: Handler? = null
    private var controlThread: HandlerThread? = null
    private var controlHandler: Handler? = null

    private var windowManager: WindowManager? = null
    private var floatingRootLayout: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private lateinit var btnStartStop: Button
    private lateinit var btnStanceSwitch: Button
    private lateinit var tvHudMetrics: TextView

    @Volatile
    private var isAiRunning: Boolean = false

    @Volatile
    private var tacticalStanceIndex: Int = 1 // 0 = Attacking, 1 = Balanced, 2 = Defensive
    private val stances = arrayOf("Attacking", "Balanced", "Defensive")

    private var lastFrameTsMs: Long = 0L
    private var currentFps: Float = 0f
    private var lastCommandTsMs: Long = 0L

    // Exact 3040x1904 calibrated coordinates
    companion object {
        const val JOY_X = 396
        const val JOY_Y = 1517
        const val JOY_RADIUS = 240

        const val BTN_PASS_SWITCH_X = 2342
        const val BTN_PASS_SWITCH_Y = 1670

        const val BTN_THROUGH_MATCHUP_X = 2433
        const val BTN_THROUGH_MATCHUP_Y = 1300

        const val BTN_SHOOT_TACKLE_X = 2775
        const val BTN_SHOOT_TACKLE_Y = 1180

        const val BTN_DASH_PRESSURE_X = 2765
        const val BTN_DASH_PRESSURE_Y = 1632

        init {
            try {
                System.loadLibrary("efootball_tactical_native")
            } catch (e: UnsatisfiedLinkError) {
                // Handled gracefully if running in pure Kotlin fallback
            }
        }
    }

    /**
     * Native C++17 / ONNX Runtime bridge returning `[actionCode, angleDeg, powerRatio, durationMs]`:
     * actionCode:
     *   0 = HOLD_OBSERVE
     *   1 = PASS_SAFE
     *   2 = ONE_TOUCH_PASS_BACK
     *   3 = SHIELD_TURN_BACK
     *   4 = DRIBBLE_SPACE
     *   5 = THROUGH_BALL
     *   6 = LOFTED_THROUGH
     *   7 = SHOOT_POWER
     *   8 = CONTROLLED_SHOT
     *   9 = CONTAIN_DEFENSE
     *  10 = INTERCEPT_PASSING_LANE
     *  11 = SWITCH_AND_PRESS
     *  12 = EMERGENCY_CLEAR
     */
    private external fun inferTacticalActionNative(
        rgbaBuffer: java.nio.ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
        stanceMode: Int
    ): FloatArray

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        initBackgroundThreads()
        createDraggableFloatingHud()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("RESULT_CODE", -1) ?: -1
        val dataIntent = intent?.getParcelableExtra<Intent>("DATA_INTENT")
        if (resultCode != -1 && dataIntent != null && mediaProjection == null) {
            setupMediaProjection(resultCode, dataIntent)
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "efootball_tactical_hud_v3"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            channelId,
            "eFootball Tactical AI Floating HUD",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("eFootball Tactical Brain v3.0")
            .setContentText("Floating HUD đang hoạt động trên màn hình")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(301, notification)
    }

    private fun initBackgroundThreads() {
        visionThread = HandlerThread("TacticalVision30Fps").apply { start() }
        visionHandler = Handler(visionThread!!.looper)
        controlThread = HandlerThread("VirtualTouchController").apply { start() }
        controlHandler = Handler(controlThread!!.looper)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createDraggableFloatingHud() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        floatingRootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#CC121A24"))
            setPadding(24, 18, 24, 18)
        }

        // Row 1: Controls ([▶ START AI] / [⏹ STOP AI] + Stance Switch)
        val controlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        btnStartStop = Button(this).apply {
            text = "▶ START AI"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E88E5"))
            setOnClickListener {
                isAiRunning = !isAiRunning
                if (isAiRunning) {
                    text = "⏹ STOP AI"
                    setBackgroundColor(Color.parseColor("#E53935"))
                } else {
                    text = "▶ START AI"
                    setBackgroundColor(Color.parseColor("#1E88E5"))
                    releaseAllTouches()
                }
            }
        }

        btnStanceSwitch = Button(this).apply {
            text = "Mode: ${stances[tacticalStanceIndex]}"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#43A047"))
            setOnClickListener {
                tacticalStanceIndex = (tacticalStanceIndex + 1) % stances.size
                text = "Mode: ${stances[tacticalStanceIndex]}"
            }
        }

        controlsRow.addView(btnStartStop)
        controlsRow.addView(btnStanceSwitch)

        // Row 2: Mini Status Telemetry (FPS, Current Decision, Latency ms)
        tvHudMetrics = TextView(this).apply {
            text = "FPS: 0.0 | Action: IDLE | Latency: 0.0 ms"
            textSize = 11f
            setTextColor(Color.parseColor("#00E676"))
            setPadding(4, 10, 4, 2)
        }

        floatingRootLayout?.addView(controlsRow)
        floatingRootLayout?.addView(tvHudMetrics)

        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 120
            y = 40
        }

        // Drag-and-drop listener for the Floating HUD
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        floatingRootLayout?.setOnTouchListener { _: View, event: MotionEvent ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = overlayParams!!.x
                    initialY = overlayParams!!.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    overlayParams!!.x = initialX + (event.rawX - touchX).roundToInt()
                    overlayParams!!.y = initialY + (event.rawY - touchY).roundToInt()
                    windowManager?.updateViewLayout(floatingRootLayout, overlayParams)
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(floatingRootLayout, overlayParams)
        } catch (e: Exception) {
            // Permission handled in MainActivity before starting service
        }
    }

    private fun setupMediaProjection(resultCode: Int, dataIntent: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpm.getMediaProjection(resultCode, dataIntent)

        // Capture at 1280x800 (matching 16:10 aspect ratio of 3040x1904) for <15ms vision inference
        val capW = 1280
        val capH = 800
        imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3)

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val tStartNs = SystemClock.elapsedRealtimeNanos()
            try {
                val nowMs = SystemClock.elapsedRealtime()
                if (lastFrameTsMs > 0L) {
                    val dtMs = (nowMs - lastFrameTsMs).coerceAtLeast(1L)
                    currentFps = 0.8f * currentFps + 0.2f * (1000f / dtMs)
                }
                lastFrameTsMs = nowMs

                if (!isAiRunning) {
                    return@setOnImageAvailableListener
                }

                val plane = image.planes[0]
                val buf = plane.buffer
                val rowStride = plane.rowStride

                val tupleOut = try {
                    inferTacticalActionNative(buf, capW, capH, rowStride, tacticalStanceIndex)
                } catch (e: UnsatisfiedLinkError) {
                    floatArrayOf(1f, 0f, 0.45f, 180f) // Fallback PASS_SAFE
                }

                val actionCode = tupleOut[0].roundToInt()
                val angleDeg = tupleOut[1]
                val powerRatio = tupleOut[2]
                val durationMs = tupleOut[3].roundToInt().coerceIn(90, 750)
                val actionName = decodeActionName(actionCode)
                val latencyMs = (SystemClock.elapsedRealtimeNanos() - tStartNs) / 1_000_000.0

                floatingRootLayout?.post {
                    tvHudMetrics.text = String.format(
                        "FPS: %.1f | %s (%.0f°, P=%.0f%%) | %.1f ms",
                        currentFps,
                        actionName,
                        angleDeg,
                        powerRatio * 100f,
                        latencyMs
                    )
                }

                // Dispatch to Virtual Touch Controller if cooldown elapsed
                if (nowMs - lastCommandTsMs >= durationMs + 60) {
                    lastCommandTsMs = nowMs
                    controlHandler?.post {
                        executeVirtualTouchTuple(actionCode, angleDeg, powerRatio, durationMs)
                    }
                }
            } finally {
                image.close()
            }
        }, visionHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "EFootballTacticalHudCapture",
            capW,
            capH,
            320,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            visionHandler
        )
    }

    private fun decodeActionName(code: Int): String = when (code) {
        1 -> "PASS_SAFE"
        2 -> "ONE_TOUCH_BACK"
        3 -> "SHIELD_TURN_BACK"
        4 -> "DRIBBLE_SPACE"
        5 -> "THROUGH_BALL"
        6 -> "LOFTED_THROUGH"
        7 -> "SHOOT_POWER"
        8 -> "CONTROLLED_SHOT"
        9 -> "CONTAIN_DEFENSE"
        10 -> "INTERCEPT_LANE"
        11 -> "SWITCH_AND_PRESS"
        12 -> "EMERGENCY_CLEAR"
        else -> "HOLD_OBSERVE"
    }

    /**
     * Virtual Touch Controller (Section 2.D):
     * Maps `(ActionCode, AngleDeg, PowerRatio, DurationMs)` into 360° smooth analog swipe
     * around `(396, 1517)` and right-cluster button taps/holds/flicks on the `3040x1904` screen.
     */
    private fun executeVirtualTouchTuple(actionCode: Int, angleDeg: Float, powerRatio: Float, durationMs: Int) {
        if (!isAiRunning || actionCode == 0) return

        val rad = Math.toRadians(angleDeg.toDouble())
        val targetJoyX = (JOY_X + cos(rad) * JOY_RADIUS).roundToInt()
        val targetJoyY = (JOY_Y + sin(rad) * JOY_RADIUS).roundToInt()
        val btnHoldMs = (100 + (powerRatio.coerceIn(0.1f, 1.0f) * 280f)).roundToInt()

        when (actionCode) {
            1, 2 -> { // PASS_SAFE or ONE_TOUCH_PASS_BACK
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY 260")
                runRootInput("input swipe $BTN_PASS_SWITCH_X $BTN_PASS_SWITCH_Y $BTN_PASS_SWITCH_X $BTN_PASS_SWITCH_Y $btnHoldMs")
            }
            3 -> { // SHIELD_TURN_BACK (180° away from presser < 1.5m)
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY $durationMs")
            }
            4 -> { // DRIBBLE_SPACE
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY $durationMs")
                if (powerRatio >= 0.55f) {
                    runRootInput("input swipe $BTN_DASH_PRESSURE_X $BTN_DASH_PRESSURE_Y $BTN_DASH_PRESSURE_X $BTN_DASH_PRESSURE_Y 260")
                }
            }
            5 -> { // THROUGH_BALL (Ground through pass)
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY 280")
                runRootInput("input swipe $BTN_THROUGH_MATCHUP_X $BTN_THROUGH_MATCHUP_Y $BTN_THROUGH_MATCHUP_X $BTN_THROUGH_MATCHUP_Y $btnHoldMs")
            }
            6 -> { // LOFTED_THROUGH (Flick Through button UP)
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY 260")
                runRootInput("input swipe $BTN_THROUGH_MATCHUP_X $BTN_THROUGH_MATCHUP_Y $BTN_THROUGH_MATCHUP_X ${BTN_THROUGH_MATCHUP_Y - 150} 195")
            }
            7 -> { // SHOOT_POWER (Inside 16m50 box)
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY 220")
                runRootInput("input swipe $BTN_SHOOT_TACKLE_X $BTN_SHOOT_TACKLE_Y $BTN_SHOOT_TACKLE_X $BTN_SHOOT_TACKLE_Y $btnHoldMs")
            }
            8 -> { // CONTROLLED_SHOT (Curled finesse shot: Flick Shoot button DOWN)
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY 220")
                runRootInput("input swipe $BTN_SHOOT_TACKLE_X $BTN_SHOOT_TACKLE_Y $BTN_SHOOT_TACKLE_X ${BTN_SHOOT_TACKLE_Y + 145} 210")
            }
            9, 10 -> { // CONTAIN_DEFENSE / INTERCEPT_PASSING_LANE (Hold Match-up + jockey angle)
                runRootInput("input swipe $JOY_X $JOY_Y $targetJoyX $targetJoyY 320")
                runRootInput("input swipe $BTN_THROUGH_MATCHUP_X $BTN_THROUGH_MATCHUP_Y $BTN_THROUGH_MATCHUP_X $BTN_THROUGH_MATCHUP_Y $durationMs")
            }
            11 -> { // SWITCH_AND_PRESS
                runRootInput("input swipe $BTN_PASS_SWITCH_X $BTN_PASS_SWITCH_Y $BTN_PASS_SWITCH_X $BTN_PASS_SWITCH_Y 95")
                runRootInput("input swipe $BTN_DASH_PRESSURE_X $BTN_DASH_PRESSURE_Y $BTN_DASH_PRESSURE_X $BTN_DASH_PRESSURE_Y $durationMs")
            }
            12 -> { // EMERGENCY_CLEAR (Immediate penalty-box clearance)
                runRootInput("input swipe $BTN_SHOOT_TACKLE_X $BTN_SHOOT_TACKLE_Y $BTN_SHOOT_TACKLE_X $BTN_SHOOT_TACKLE_Y 210")
            }
        }
    }

    private fun runRootInput(cmd: String) {
        try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor()
        } catch (e: Exception) {
            // Ignored if stop triggered
        }
    }

    private fun releaseAllTouches() {
        controlHandler?.post {
            runRootInput("input motionevent UP $JOY_X $JOY_Y")
        }
    }

    override fun onDestroy() {
        isAiRunning = false
        releaseAllTouches()
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
            floatingRootLayout?.let { windowManager?.removeView(it) }
            visionThread?.quitSafely()
            controlThread?.quitSafely()
        } catch (e: Exception) {
            // Safe cleanup
        }
        super.onDestroy()
    }
}
